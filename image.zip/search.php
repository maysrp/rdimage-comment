<!DOCTYPE html>
<html>
<head>
	<title>图片:<?php echo $name ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.0/css/bootstrap.min.css">
        <script src="https://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://cdn.bootcss.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script type='text/javascript' src="https://cdn.staticfile.org/clipboard.js/1.5.15/clipboard.min.js"></script>
        <style type="text/css">
        	
        </style>
</head>
<?php 
        $tag=isset($_GET['tag'])?trim($_GET['tag']):"0";
?>
<body class="container">
        <div class="he row text-center">
                <h2><a href="index.html" class="text-muted">每日一图</a><small ><a href="" class="text-primary">标签搜索</a></small></h2>
        </div>
        <div class="se row">
                <div class="col-md-6 col-md-offset-3">
                        <div class="input-group">
                                <input type="text" class="form-control tagg" name="tag" placeholder="搜索标签名称" value="<?php echo $tag ?>">
                                <div class="input-group-btn">
                                        <button class="btn btn-default" onclick="tag_search()">搜索</button>
                                </div>
                        </div>
                </div>
        </div>
        <div class="co row" style="margin-top:15px; ">
                
        </div>
        <script type="text/javascript">
                tag_search();
                function tag_search() {
                        var tag=$(".tagg").val();
                        if(tag){
                                $.ajax({
                                        url:'tag.php?type=search&id='+tag,
                                        success:function(data){
                                                tagadd(data);
                                        }
                                })
                        }
                }
                function tagadd(data){
                        $(".co").html("");
                        if(!data[0]){
                                $(".co").html("<div class='row text-center'><h3 class='text-muted'>无数据</h3></div>");
                        }
                        for (x in data){
                                var a=$("<a href='image.php?id="+data[x].id+"'><h3>"+data[x].id+" <button class='btn btn-sm btn-info'>"+data[x].name+" <span class='badge'>"+data[x].num+"</span></button></h3></a>");
                                var div=$("<div class='col-md-6'></div>");
                                a.appendTo(div);
                                div.appendTo(".co");
                        }
                }

                $(document).keypress(function(e) {  
                        if(e.which == 13) {  
                                tag_search();
                        }  
                });
        </script>
</body> 
</html>       