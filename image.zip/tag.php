<?php
	include_once 'class/image.php';
	include_once 'class/medoo.php';
	$id=isset($_GET['id'])?trim($_GET['id']):"";
	$type=isset($_GET['type'])?trim($_GET['type']):"nomal";
	$name=isset($_GET['name'])?trim($_GET['name']):"";//添加
	$image=new image();
	switch ($type) {
		case 'nomal':
			$info=$image->tag_id($id);
			break;
		case 'search':
			$info=$image->tag_search($id);//相当于name
			break;
		case 'add':
			$info=$image->tag($name,$id);
			break;
		default:
			# code...
			break;
	}
	$image->json($info);

