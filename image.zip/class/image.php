<?php
	class image{
		public $db;
		public function __construct(){
			$this->db= new medoo([
    				'database_type' => 'mysql',
 				    'database_name' => 'image',
 				    'server' => 'localhost',
 			        'username' => 'root',
  				    'password' => '',
			        'charset' => 'utf8',
   			 		'port' => 3306,
    				'prefix' => 'info_',
			]);
		}
		public function tag_search($name){
			$where['name[~]']=$name;
			$where['ORDER']="num";
			//$where['ORDER']['num']='';
			//$where['ORDER']['profile_id']="DESC";
			$info=array("id","num","name");
			$ba=$this->db->select('tag',$info,$where);
			$ba=array_reverse($ba);
			return $ba;
		}
		public function tag_id($id){
			$where['id']=$id;
			$info=array("num","name","id");
			$ba=$this->db->select('tag',$info,$where);
			return $ba;
		}
		public function tag($name,$id){
			if(!$name){
				$re['status']=false;
				$re['con']="无内容";
				return $re;
			}
			if($this->jugg()){
				if($this->is_tag($name,$id)){
					$this->tag_add($name,$id);
				}else{
					$this->tag_create($name,$id);
				}
				$re['status']=true;
				$re['con']=$this->tag_id($id);
			}else{
				$re['status']=false;
				$re['con']="已经超出每日IP添加标签限制";
			}
			return $re;
		}
		protected function is_tag($name,$id){
			$where['AND']['id']=$id;
			$where['AND']['name']=$name;
			return $this->db->has("tag",$where);
		}
		protected function tag_add($name,$id){
			$where['AND']['id']=$id;
			$where['AND']['name']=$name;
			$ac=array("info");
			$info=$this->db->select("tag",$ac,$where);
			$jsona=json_decode($info[0]['info'],true);
			$newa['ip']=$_SERVER['REMOTE_ADDR'];
			$newa['time']=time();
			$jsona[$_SERVER['REMOTE_ADDR']]=$newa;
			$update['num']=count($jsona);
			$update['info']=json_encode($jsona);
			$update['uptime']=time();
			//var_dump($update);
			$this->db->update('tag',$update,$where);
		}
		protected function tag_create($name,$id){
			$newa['ip']=$_SERVER['REMOTE_ADDR'];
			$newa['time']=time();
			$jsona[$_SERVER['REMOTE_ADDR']]=$newa;
			$insert['info']=json_encode($jsona);
			$insert['id']=$id;
			$insert['name']=$name;
			$insert['time']=time();
			$insert['ip']=$_SERVER['REMOTE_ADDR'];
			$insert['num']=1;
			$this->db->insert('tag',$insert);
		}
		protected function jugg(){//IP
			$ip=$_SERVER['REMOTE_ADDR'];
			$num=$this->ip_num($ip);
			if($num>100){
				return false;
			}else{
				$this->ip($ip);
				return true;
			}


		}
		protected function ip($ip){
			if($this->ip_has($ip)){
				$this->ip_update($ip);
			}else{
				$this->ip_add($ip);
			}
		}
		protected function ip_num($ip){
			$where['ip']=$ip;
			$info=$this->db->select('ip','*',$where);
			$date=date("Ymd");
			if($date==$info[0]['time']){
				return $info[0]['num'];
			}else{
				return 0;
			}
		}
		protected function ip_update($ip){
			$num=$this->ip_num($ip);
			$where['ip']=$ip;
			$update['num']=$num+1;
			$update['ip']=$ip;
			$update['time']=date("Ymd");
			$this->db->update('ip',$update,$where);
			//$update['time']=date("Ymd");
		}
		protected function ip_add($ip){
			$insert['ip']=$ip;
			$insert['time']=date("Ymd");
			$this->db->insert('ip',$insert);
		}
		protected function ip_has($ip){
			$where['ip']=$ip;
			return $this->db->has("ip",$where);
		}
		public function support(){

		}
		public function json($info){
			header('Content-type:text/json');
			echo json_encode($info);
		}
		public function json_head(){
			header('Content-type:text/json');
		}

	}	