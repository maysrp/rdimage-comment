<?php
	$id=isset($_GET['id'])?$_GET['id']:"";
	$no=base64_decode($id);
	//$no="./base64/001.JPG.64";
	 if(!is_file($no)){
	 	header("Location:index.html");
	 }
	$name=md5($no);
	
	$dir=str_replace("/base64/","/image/",$no);
	$length=strlen($dir);
	$dir=substr($dir,0,$length-3);
	$info=getimagesize($dir);
	if($info){
		$mime=$info['mime'];
		$img=file_get_contents($no);
		$data="data:".$mime.";base64,".$img;
	}else{
		header("Location:index.html");
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>图片:<?php echo $name ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.0/css/bootstrap.min.css">
        <script src="https://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://cdn.bootcss.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script type='text/javascript' src="https://cdn.staticfile.org/clipboard.js/1.5.15/clipboard.min.js"></script>
        <style type="text/css">
        	.btnx{
        		margin: 5px;
        	}
        </style>
</head>
<body class="container">
	<div class="row" style="margin: 30px;">
		<h2><a href="index.html">每日一图</a></h2>
	</div>
	<div class="row">
		<div class="col-md-4 col-md-offset-8">
				<div class="input-group">
						<input type="text" name="tag" class="form-control tagg" placeholder="标签">
						<div class="input-group-btn">
							<button class="btn btn-primary" onclick="search()">搜索</button>
						</div>
				</div>
			</div>
	</div>
	<div class="row text-center" >
		<h3>图片:<?php echo $id ?></h3>
		<div class="text-center row">
			<img src="<?php echo $data ?>" width="100%">
		</div>
	</div>
	<!-- <div class="row url" style="margin-top:30px; ">
		<div class="input-group">
			<div class="input-group-addon">
				<span>图片外链</span>
			</div>
			<input type="text" class="form-control" id="end" name="url" value="
				<?php
					echo "<img width='100%' src='http://".$_SERVER['HTTP_HOST']."/url.php?id=".$id."'/>";
				?>
			">
			<div class="input-group-btn">
				<button class="btn btn-info" id="copy"  data-clipboard-target="#end">复制链接</button>
			</div>
			<script type='text/javascript'>
				var clipboard = new Clipboard('#copy');
			</script>
		</div>
	</div> -->
	<div class="tagdiv row" style="margin-top:15px;">
		<button class="btn btn-success" data-toggle="modal" data-target=".addtag">添加标签<span class="glyphicon glyphicon-plus"></span></button>
		<div class="row tag">
			
		</div>
	</div>
	<script type="text/javascript">
		ac_tag();
		function ac_tag(){
			$.ajax({
				url:'tag.php?id=<?php echo $id ?>',
				success:function(data){
					tag(data);
				}
			})
		}
		function tag(data){
			$(".tag").html("");
			for (x in data){
				var span=$("<a class='btn btn-default btnx btn-sm' href='search.php?tag="+data[x].name+"'>"+data[x].name+" <span class='badge'>"+data[x].num+"</span></a>");
				span.appendTo(".tag");
			}
		}
	</script>
	<div class="row comment">
		<div id="cloud-tie-wrapper" class="cloud-tie-wrapper"></div>
		<script src="https://img1.cache.netease.com/f2e/tie/yun/sdk/loader.js"></script>
		<script>
		var cloudTieConfig = {
		  url: document.location.href, 
		  sourceId: "",
		  productKey: "3cb7af11669242babf7e8fafca356c3f",
		  target: "cloud-tie-wrapper"
		};
		var yunManualLoad = true;
		Tie.loader("aHR0cHM6Ly9hcGkuZ2VudGllLjE2My5jb20vcGMvbGl2ZXNjcmlwdC5odG1s", true);
		</script>
	</div>
	<div class="row">
		<h3><a href="index.html">返回首页</a></h3>
	</div>
	<div class="row footer">
		<P class="text-muted">图片全部来自网络若侵权请发邮件到admin[at]nyanya.tv,我们会及时删除。</P>
	</div>
</body>
<div class="modal fade addtag" >
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
  		<div class="modal-header">
  			<h3 class="modal-title">添加标签</h3>
  		</div>
  		<div class="modal-body">
  			<input type="text" name="name" class="form-control name" >
  		</div>
  		<div class="modal-footer">
  			<button class="btn btn-success addtagbtn" >添加</button> <button type="button" class="btn btn-default" data-dismiss="modal">放弃</button>
  		</div>
    </div>
  </div>
 <script type="text/javascript">
	$(".addtagbtn").click(function(){
			var name=$(".name").val();
			$.ajax({
				url:'tag.php?type=add&id=<?php echo $id ?>&name='+name,
				success:function(data){
					if(data.status){
						tag(data.con);
					}else{
						confirm(data.con);
					}
					$(".addtag").modal('hide');
					name=$(".name").val("");
				}
			})
		})
	function search(){
		var tag=$(".tagg").val();
		window.location.href="search.php?tag="+tag;
	}
</script>
</div>
</html>