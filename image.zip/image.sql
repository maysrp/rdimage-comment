-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2017-05-28 07:09:03
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `image`
--

-- --------------------------------------------------------

--
-- 表的结构 `info_ip`
--

CREATE TABLE IF NOT EXISTS `info_ip` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `ip` text NOT NULL,
  `time` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `info_ip`
--

INSERT INTO `info_ip` (`pid`, `ip`, `time`, `num`) VALUES
(3, '127.0.0.1', 20170528, 1);

-- --------------------------------------------------------

--
-- 表的结构 `info_support`
--

CREATE TABLE IF NOT EXISTS `info_support` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `ip` int(11) NOT NULL,
  `id` text NOT NULL COMMENT '作品id',
  `info` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `info_tag`
--

CREATE TABLE IF NOT EXISTS `info_tag` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 NOT NULL,
  `id` text NOT NULL,
  `time` int(11) NOT NULL,
  `ip` text NOT NULL,
  `num` int(11) NOT NULL,
  `uptime` int(11) NOT NULL,
  `info` longtext NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `info_tag`
--

INSERT INTO `info_tag` (`tid`, `name`, `id`, `time`, `ip`, `num`, `uptime`, `info`) VALUES
(6, 'fei', 'Li9iYXNlNjQvMDAxLkpQRy42NA==', 1495907659, '127.0.0.1', 3, 1495907829, '{"127.0.0.12":{"ip":"127.0.0.1","time":1495907703},"127.0.0a.1":{"ip":"127.0.0.1","time":1495907807},"127.0.0.1":{"ip":"127.0.0.1","time":1495907829}}'),
(7, '小姐姐', 'Li9iYXNlNjQvMDAxLkpQRy42NA==', 0, '', 1, 1495911868, '{"127.0.0.1":{"ip":"127.0.0.1","time":1495911868}}'),
(8, '鹿岛', 'Li9iYXNlNjQvMDAxLkpQRy42NA==', 1495911647, '127.0.0.1', 1, 0, '{"127.0.0.1":{"ip":"127.0.0.1","time":1495911647}}'),
(9, '飞机', 'Li9iYXNlNjQvMDAxLkpQRy42NA==', 1495911761, '127.0.0.1', 1, 0, '{"127.0.0.1":{"ip":"127.0.0.1","time":1495911761}}'),
(10, '你好！', 'Li9iYXNlNjQvMDAxLkpQRy42NA==', 1495911859, '127.0.0.1', 1, 0, '{"127.0.0.1":{"ip":"127.0.0.1","time":1495911859}}'),
(11, 'ac', 'Li9iYXNlNjQvMDAxLkpQRy42NA==', 1495947799, '127.0.0.1', 1, 0, '{"127.0.0.1":{"ip":"127.0.0.1","time":1495947799}}');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
